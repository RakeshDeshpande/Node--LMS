const { expect, driver, webdriver, path, service, chrome, By, until, options, } = require('../config')

describe('App', function() {
  it('should add update  delete',  async function(){
    this.timeout(30000);

     

     driver.get('http://localhost:8000')


     function makeid(len) {
      var text = "";
      var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

      for (var i = 0; i < len; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

      return text;
    }

    let randName=makeid(8);

  await driver.wait(until.elementLocated(By.id("register"))).click()

  let fullName= await driver.wait(until.elementLocated(By.id("fullName")))
  await fullName.clear()
  await fullName.sendKeys(randName);
  let emailId= await driver.wait(until.elementLocated(By.id("emailId")))
  await emailId.clear()
  await emailId.sendKeys(randName+"@doselect.com");
  let password= await driver.wait(until.elementLocated(By.id("password")))
  await password.clear()
  await password.sendKeys("Test@123");
  let confirmPassword= await driver.wait(until.elementLocated(By.id("confirmPassword")))
  await confirmPassword.clear()
  await confirmPassword.sendKeys("Test@123");
  await driver.wait(until.elementLocated(By.id("submit"))).click();

  await driver.navigate().to('http://localhost:8000/register')
  let usernameTb= await driver.wait(until.elementLocated(By.id("usernameTb")))
  await usernameTb.clear()
  await usernameTb.sendKeys(randName+"@doselect.com");
  let loginPasswodTb= await driver.wait(until.elementLocated(By.id("loginPasswodTb")))
  await loginPasswodTb.clear()
  await loginPasswodTb.sendKeys("Test@123");

  await driver.wait(until.elementLocated(By.id("submit-login"))).click();
    await driver.navigate().refresh();
    await driver.navigate().to('http://localhost:8000/createCourse')
    let nameTb= await driver.wait(until.elementLocated(By.id("nameTb")))
    await nameTb.clear()
    await nameTb.sendKeys(makeid(12));
    let oneLinerTb= await driver.wait(until.elementLocated(By.id("oneLinerTb")))
    await oneLinerTb.clear()
    await oneLinerTb.sendKeys(makeid(10));
    let durationTb= await driver.wait(until.elementLocated(By.id("durationTb")))
    await durationTb.clear()
    await durationTb.sendKeys("1");
    let languageTb= await driver.wait(until.elementLocated(By.id("languageTb")))
    await languageTb.clear()
    await languageTb.sendKeys(makeid(8));

    // let description= await driver.wait(until.elementLocated(By.id("description")))
    // await description.clear()
    // await description.sendKeys(makeid(20));
     await driver.wait(until.elementLocated(By.id("courseSubmit"))).click();


   await  driver.navigate().to("http://localhost:8000/updateCourse")
     durationTb= await driver.wait(until.elementLocated(By.id("durationTb")))
    await durationTb.clear()
    await durationTb.sendKeys("2");
    await driver.wait(until.elementLocated(By.id("updateCourse"))).click();
    await driver.navigate().to('http://localhost:8000/createCourse')
     nameTb= await driver.wait(until.elementLocated(By.id("nameTb")))
    await nameTb.clear()
    await nameTb.sendKeys(makeid(12));
     oneLinerTb= await driver.wait(until.elementLocated(By.id("oneLinerTb")))
    await oneLinerTb.clear()
    await oneLinerTb.sendKeys(makeid(10));
     durationTb= await driver.wait(until.elementLocated(By.id("durationTb")))
    await durationTb.clear()
    await durationTb.sendKeys("1");
     languageTb= await driver.wait(until.elementLocated(By.id("languageTb")))
    await languageTb.clear()
    await languageTb.sendKeys(makeid(8));

    // let description= await driver.wait(until.elementLocated(By.id("description")))
    // await description.clear()
    // await description.sendKeys(makeid(20));
     await driver.wait(until.elementLocated(By.id("courseSubmit"))).click();

    await driver.navigate().to("http://localhost:8000/deleteCourse")

    let before= await driver.wait(until.elementsLocated(By.className("deleteCourse")))
    let beforeLength=await before.length
    let ele=await driver.wait(until.elementsLocated(By.className("deleteCourse")))
    await ele[0].click()
    let after=await driver.wait(until.elementsLocated(By.className("deleteCourse")))
    let afterLength=await after.length

    await expect(beforeLength-1).to.equal(afterLength)






  })
})