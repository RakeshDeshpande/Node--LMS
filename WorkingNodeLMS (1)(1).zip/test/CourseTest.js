var request = require("request");
var should = require("should");
var supertest = require("supertest");

var server = supertest.agent("http://localhost:8000");

describe('creation and deletion of Course', function () {
    function makeid(len) {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < len; i++)
            text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
    }
    var rand = makeid(8)
    it("reg ", function () {
        console.log('reg', rand)
        server
            .post("/register")
            .send({

                name: rand,
                emailId: rand + '@doselect.com',
                password: rand,

            })
            .expect("Content-type", /json/)
            .expect(200)
            .end(function (err, res) {
                res.status.should.equal(200);
                res.body.should.have.property("message", "Registration is successful");


            });

    })
    it('login', function (done) {
        console.log({
            emailId: rand + '@doselect.com',
            password: rand
        })
        server.post("/login").send({
                emailId: rand + '@doselect.com',
                password: rand
            }).expect("Content-type", /json/)
            .expect(200)
            .end(function (err, res) {
                res.status.should.equal(200);
                res.body.user.should.have.property("name", rand);
                done();
            });

    })


})