// const {Builder, By, Key, until,Capabilities} = require('selenium-webdriver');
// // const phantomjs = require('phantomjs-prebuilt');
// // const chrome = require('/opt/chromedriver');
// const chromeCapabilities = Capabilities.chrome();
// chromeCapabilities.set('chromeOptions', {
//   'args': [ '--disable-gpu','--enable-javascript']
// });
// // '--headless',
// const expect = require('chai').expect
// var webdriver = require('selenium-webdriver'),
//     chrome    = require('selenium-webdriver/chrome')
//     By        = webdriver.By,
//     until     = webdriver.until,
//     options   = new chrome.Options();
//     options.addArguments('headless'); // note: without dashes
//     options.addArguments('disable-gpu')
//     options.addArguments('no-sandbox')
// var path = '/opt/chromedriver';
// var service = new chrome.ServiceBuilder(path).build();
//     chrome.setDefaultService(service);
// var driver = new webdriver.Builder()
//     .forBrowser('chrome')
//     .withCapabilities(webdriver.Capabilities.chrome()) 
//     .setChromeOptions(options)                         // note this
//     .build();
// var expect = require('chai').expect
const { expect, driver, webdriver, path, service, chrome, By, until, options, } = require('../config')
describe('App', function() {
  it('should be able to edit user details ',  async function(){
    this.timeout(30000);

     

     driver.get('http://localhost:8000')

     function makeid() {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < 8; i++)
          text += possible.charAt(Math.floor(Math.random() * possible.length));

        return text;
      }

      let randName=makeid();

    await driver.wait(until.elementLocated(By.id("register"))).click()

    let fullName= await driver.wait(until.elementLocated(By.id("fullName")))
    await fullName.clear()
    await fullName.sendKeys(randName);
    let emailId= await driver.wait(until.elementLocated(By.id("emailId")))
    await emailId.clear()
    await emailId.sendKeys(randName+"@doselect.com");
    let password= await driver.wait(until.elementLocated(By.id("password")))
    await password.clear()
    await password.sendKeys("Test@123");
    let confirmPassword= await driver.wait(until.elementLocated(By.id("confirmPassword")))
    await confirmPassword.clear()
    await confirmPassword.sendKeys("Test@123");
    await driver.wait(until.elementLocated(By.id("submit"))).click();

    await driver.navigate().to('http://localhost:8000/register')
    let usernameTb= await driver.wait(until.elementLocated(By.id("usernameTb")))
    await usernameTb.clear()
    await usernameTb.sendKeys(randName+"@doselect.com");
    let loginPasswodTb= await driver.wait(until.elementLocated(By.id("loginPasswodTb")))
    await loginPasswodTb.clear()
    await loginPasswodTb.sendKeys("Test@123");

    await driver.wait(until.elementLocated(By.id("submit-login"))).click();

    await driver.navigate().to('http://localhost:8000/editProfile')

    let ele= await driver.wait(until.elementLocated(By.id("emailIdTb")))
    await ele.getAttribute('value').then(val=>{
            expect(val).to.equal(randName+'@doselect.com')
    });





  })
})