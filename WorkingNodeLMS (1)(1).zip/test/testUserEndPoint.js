var request = require("request");
var should = require("should");
var supertest = require("supertest");


var server = supertest.agent("http://localhost:8000");

function makeid(len) {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < len; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}
var rand = makeid(10)
it("register ", function (done) {


    server
        .post("/register")
        .send({

            name: rand,
            emailId: rand + '@doselect.com',
            password: rand,

        })
        .expect("Content-type", /json/)
        .expect(200)
        .end(function (err, res) {
            res.status.should.equal(200);
            res.body.should.have.property("message", "Registration is successful");

            done();
        });
});