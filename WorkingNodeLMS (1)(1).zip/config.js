var webdriver = require('selenium-webdriver'),
    chrome    = require('selenium-webdriver/chrome'),
    By        = webdriver.By,
    until     = webdriver.until,
    options   = new chrome.Options();
    options.addArguments('headless'); // note: without dashes
    options.addArguments('disable-gpu')
    options.addArguments('no-sandbox')
var path = '/opt/chromedriver';
var service = new chrome.ServiceBuilder(path).build();
    chrome.setDefaultService(service);
var driver = new webdriver.Builder()
    .forBrowser('chrome')
    .withCapabilities(webdriver.Capabilities.chrome()) 
    .setChromeOptions(options)                         // note this
    .build();
var expect = require('chai').expect
module.exports = {
    webdriver,
    chrome,
    By,
    until,
    options,
    path,
    service,
    driver,
    expect
}