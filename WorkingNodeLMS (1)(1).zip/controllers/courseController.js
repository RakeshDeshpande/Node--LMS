var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({extended: false});
var mongoose = require('mongoose');

// mongoose.connect('mongodb://localhost/lms', function (err) {
//    if (err) throw err;
//    console.log('Database Successfully connected');
 
// });

var courseSchema = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    name : String,
    oneLiner: String,
    description: String,
    category: String,
    duration: Number,
    instructor: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User'
    },
    /*lessons: [ 
        {
            type: mongoose.Schema.Types.ObjectId, 
            ref: 'Lesson'
        }
    ],*/
    language : String,
    created: { 
        type: Date,
        default: Date.now
    },
    coverPhoto : String
});

var Course = mongoose.model('Course',courseSchema);

/*var myCourse = new Course({
    _id: new mongoose.Types.ObjectId(),
    name: 'The Web Developer Bootcamp',
    oneLiner : 'The only course you need to learn web development - HTML, CSS, JS, Node, and More!',
    language: 'English',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    category: 'Software',
    duration: 42.5,
    instructor: '5abde0e20ec55809486cc494'
});


myCourse.save(function(err){
    if(err) throw err;
    console.log('course saved');
}); 

myCourse = new Course({
    _id: new mongoose.Types.ObjectId(),
    name: 'The Python Mega Course: Build 10 Real World Applications',
    oneLiner : 'The only Python course covering web, databases, web scraping, data science, web visualizations, image processing & more!',
    language: 'English',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    category: 'Web Design',
    duration: 23.5,
    instructor: '5abde0e20ec55809486cc495'
});

myCourse.save(function(err){
    if(err) throw err;
    console.log('course saved');
}); 

myCourse = new Course({
    _id: new mongoose.Types.ObjectId(),
    name: 'Complete Java Masterclass',
    oneLiner: 'Learn to master Java 8 and Java 9 core development step-by-step, and make your first unique, advanced program in 30 days',
    language: 'English',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    category: 'Web Development',
    duration: 72,
    instructor: '5abde0e20ec55809486cc496'
});

myCourse.save(function(err){
    if(err) throw err;
    console.log('course saved');
});  

myCourse = new Course({
    _id: new mongoose.Types.ObjectId(),
    name: 'The Complete Web Developer Course 2.0',
    oneLiner: 'Learn Web Development by building 25 websites and mobile apps using HTML, CSS, Javascript, PHP, Python, MySQL & more!',
    language: 'English',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    category: 'Web Development',
    duration: 72,
    instructor: '5abde0e20ec55809486cc496',
    lessons:[
        {
            title: 'Introduction to HTML 5',
            description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.'
        },
        {
            title: 'Introduction To CSS 3 Section',
            description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.'
        },
        {
            title: 'Introduction To Javascript Section',
            description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.'
        },
        {
            title: 'Introduction To jQuery Section',
            description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.'
        },
        {
            title: 'Introduction To Bootstrap 4 Section',
            description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.'
        },
        {
            title: 'Introduction To Wordpress Section',
            description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.'
        }
    ]
});

myCourse.save(function(err){
    if(err) throw err;
    console.log('course saved');
}); 
*/

/*module.exports = function(app){
    app.get('/',function(req,resp){
        // Course.find({},function(err,data){
        //     if(err) throw err;
        //     resp.render('todo',{todos:data });
        //  });

         Course.find({}).sort('-created')
         .populate('instructor')
        .limit(10)
        .exec(function(err, courses) {
            if (err) throw err;
            resp.render('index',{course:courses });
        });
    });


    app.get('/courseDetails/:id',function(req,resp){
        // Course.find({},function(err,data){
        //     if(err) throw err;
        //     resp.render('todo',{todos:data });
        //  });

         Course.findById(req.params.id)
         .populate('instructor')
         .exec(function(err, data) {
            if (err) throw err;
            resp.render('courseDetails',{course:data });
         });
    });
}; */

module.exports = Course;